# Notification Service

A simple Python package for sending notifications through the Pushover service.


## Build

```bash
pip install -r requirements.txt
```

## Installation

```bash
pip install .
```
