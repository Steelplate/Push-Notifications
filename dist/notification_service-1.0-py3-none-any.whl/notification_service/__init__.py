# notification_service/__init__.py

from .service import Service
